<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index');
Route::post('/', 'HomeController@index')->name('show_bikes');

Auth::routes();

Route::get('/admin/panel', 'Admin\PanelController@index')
    ->middleware('auth', 'level-check');

Route::post('/admin/panel/register-motor', 'Admin\PanelController@storeMotor')
    ->name('register_motor');

Route::get('/bike/{bike}', 'HomeController@showMotor')->name('show_motor');

Route::post('/sorting', 'HomeController@sortAjax')->name('sort_bikes');
//Route::get('/home', 'HomeController@index')->name('home');

<div class="container" id="motors" style="margin-bottom: 15px;">

    @foreach($motors as $motor)

        <div class="row">

            <div class="col-md-6">
                <img src="{{ $motor->image }}" style="width: 100%">
            </div>

            <div class="col-md-6">
                <h2><a href="{{ route('show_motor', ['id' => $motor->id]) }}"
                    >{{ $motor->model }}</a></h2>
                <p>Make : {{ $motor->make }}</p>
                <p>Color : {{ $motor->color }}</p>
                <p>Weight : {{ $motor->weight }} Kg</p>
                <p>Price : $ {{ $motor->price }}</p>
            </div>
        </div>

    @endforeach

    <div>
        {{ $motors->links() }}
    </div>

</div>
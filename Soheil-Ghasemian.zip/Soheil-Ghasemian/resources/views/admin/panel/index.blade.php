@extends('admin.panel.master')

@section('content')

    <form method="post" action="{{ route('register_motor') }}" enctype="multipart/form-data">

        {{ csrf_field()  }}

        @foreach($errors->all() as $error)
            <div class="alert alert-danger" role="alert">
                {{ $error }}
            </div>
        @endforeach

        <div class="form-group">
            <label for="model">Model</label>
            <input type="text" class="form-control" value="{{ old('model') }}"
                   id="model" name="model" placeholder="Enter Model">
        </div>

        <div class="form-group">
            <label for="make">Make</label>
            <select class="form-control" id="make" name="make">
                <option value="">Make</option>
                <option value="BMW">BMW</option>
                <option value="Yamaha">Yamaha</option>
                <option value="Honda">Honda</option>
                <option value="Suzuki">Suzuki</option>
                <option value="Kawasaki">Kawasaki</option>
            </select>
        </div>

        <div class="form-group">
            <label for="color">Color</label>
            <select name="color" class="form-control" id="color">
                <option value="">Color</option>
                <option value="BLACK">BLACK</option>
                <option value="BLUE">BLUE</option>
                <option value="BLUE/WHITE">BLUE/WHITE</option>
                <option value="Black/Orange">Black/Orange</option>
                <option value="GREEN">GREEN</option>
                <option value="GREY">GREY</option>
                <option value="NIGHT FLUO">NIGHT FLUO</option>
                <option value="ORANGE">ORANGE</option>
                <option value="R/W/BLUE">R/W/BLUE</option>
                <option value="RACE BLUE">RACE BLUE</option>
                <option value="RADICAL RED">RADICAL RED</option>
                <option value="RED">RED</option>
                <option value="RED/BLACK">RED/BLACK</option>
                <option value="SILVER">SILVER</option>
                <option value="STONEHENGE GREY">STONEHENGE GREY</option>
                <option value="TECH BLACK">TECH BLACK</option>
                <option value="WHITE">WHITE</option>
                <option value="YELLOW">YELLOW</option>
            </select>
        </div>

        <div class="form-group">
            <label for="weight">Weight (Kg)</label>
            <input type="number" class="form-control" value="{{ old('weight') }}}"
                   name="weight" id="weight" placeholder="Weight">
        </div>

        <div class="form-group">
            <label for="weight">Price</label>
            <input type="number" class="form-control" value="{{ old('price') }}}"
                   name="price" id="price" placeholder="Price">
        </div>

        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control-file" id="image" name="image">
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" rows="6"
                      id="description" name="description">{{ old('description') }}</textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>

    </form>

@stop
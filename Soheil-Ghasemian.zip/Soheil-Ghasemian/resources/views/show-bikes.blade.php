@extends('layouts.app')

@section('content')

    <div class="container" style="margin-bottom: 15px;">

        <div>
            <img src="{{ $bike->image }}" style="height: 400px">
        </div>

        <div style="margin-top: 20px;">
            <h3>Model : {{ $bike->model }}</h3>
            <h3>Make : {{ $bike->make }}</h3>
            <h3>Color : {{ $bike->color }}</h3>
            <h3>Weight : {{ $bike->weight }} Kg</h3>
            <h3>Price : $ {{ $bike->weight }}</h3>
        </div>

        <div>
            <h1>Description</h1>
            <p>{{ $bike->description }}</p>
        </div>

    </div>

@stop
<?php $__env->startSection('content'); ?>

    <div style="text-align: center">
        <div class="form-group">
            <label for="sorting">Sort By : </label>
            <select id="sorting" name="sorting" style="padding: 5px;">
                <option value="price">price</option>
                <option value="date">date</option>
            </select>
        </div>
        <div class="form-group">
            <label for="colors">Choose Color : </label>
            <select id="colors" name="colors" style="padding: 5px;">
                <option value="">Color</option>
                <option value="BLACK">BLACK</option>
                <option value="BLUE">BLUE</option>
                <option value="BLUE/WHITE">BLUE/WHITE</option>
                <option value="Black/Orange">Black/Orange</option>
                <option value="GREEN">GREEN</option>
                <option value="GREY">GREY</option>
                <option value="NIGHT FLUO">NIGHT FLUO</option>
                <option value="ORANGE">ORANGE</option>
                <option value="R/W/BLUE">R/W/BLUE</option>
                <option value="RACE BLUE">RACE BLUE</option>
                <option value="RADICAL RED">RADICAL RED</option>
                <option value="RED">RED</option>
                <option value="RED/BLACK">RED/BLACK</option>
                <option value="SILVER">SILVER</option>
                <option value="STONEHENGE GREY">STONEHENGE GREY</option>
                <option value="TECH BLACK">TECH BLACK</option>
                <option value="WHITE">WHITE</option>
                <option value="YELLOW">YELLOW</option>
            </select>
        </div>
    </div>

    <section class="motors">
        <?php echo $__env->make('bikes.load', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>

    <script>

        document.addEventListener("DOMContentLoaded", function () {
            $("#sorting").change(function () {
                var sort = this.value;
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    method: "POST",
                    url: "<?php echo e(route('show_bikes')); ?>",
                    data: {
                        _token: CSRF_TOKEN,
                        sort: sort,
                        dataType: 'JSON',
                        async: true
                    }
                })
                    .done(function (data) {
                        /*$(data.motors['data']).each(function (motor) {
                            alert(motor['id']);
                        });*/

                        $('.motors').html(data);
                    })
                    .fail(function () {
                        alert('Articles could not be loaded.');
                    });
            });

            $("#colors").change(function () {
                var color = this.value;
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    method: "POST",
                    url: "<?php echo e(route('show_bikes')); ?>",
                    data: {
                        _token: CSRF_TOKEN,
                        color: color,
                        dataType: 'JSON',
                        async: true
                    }
                })
                    .done(function (data) {
                        $('.motors').html(data);
                    })
                    .fail(function () {
                        alert('Articles could not be loaded.');
                    });
            });

        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
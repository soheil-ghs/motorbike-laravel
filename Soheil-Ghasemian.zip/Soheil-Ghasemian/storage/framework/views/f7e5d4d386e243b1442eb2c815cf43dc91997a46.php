<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-bottom: 15px;">

        <div>
            <img src="<?php echo e($bike->image); ?>" style="height: 400px">
        </div>

        <div style="margin-top: 20px;">
            <h3>Model : <?php echo e($bike->model); ?></h3>
            <h3>Make : <?php echo e($bike->make); ?></h3>
            <h3>Color : <?php echo e($bike->color); ?></h3>
            <h3>Weight : <?php echo e($bike->weight); ?> Kg</h3>
            <h3>Price : $ <?php echo e($bike->weight); ?></h3>
        </div>

        <div>
            <h1>Description</h1>
            <p><?php echo e($bike->description); ?></p>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
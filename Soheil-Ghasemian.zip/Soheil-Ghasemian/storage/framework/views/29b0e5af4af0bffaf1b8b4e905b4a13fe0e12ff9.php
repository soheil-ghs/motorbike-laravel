<div class="container" id="motors" style="margin-bottom: 15px;">

    <?php $__currentLoopData = $motors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row">

            <div class="col-md-6">
                <img src="<?php echo e($motor->image); ?>" style="width: 100%">
            </div>

            <div class="col-md-6">
                <h2><a href="<?php echo e(route('show_motor', ['id' => $motor->id])); ?>"
                    ><?php echo e($motor->model); ?></a></h2>
                <p>Make : <?php echo e($motor->make); ?></p>
                <p>Color : <?php echo e($motor->color); ?></p>
                <p>Weight : <?php echo e($motor->weight); ?> Kg</p>
                <p>Price : $ <?php echo e($motor->weight); ?></p>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div>
        <?php echo e($motors->links()); ?>

    </div>

</div>
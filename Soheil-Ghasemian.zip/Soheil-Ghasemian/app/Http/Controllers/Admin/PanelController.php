<?php

namespace App\Http\Controllers\Admin;

use App\MotorBike;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PanelController extends Controller
{

    public function index()
    {
        return view('admin.panel.index');
    }

    public function storeMotor(Request $request)
    {
        $this->validate($request, [
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
            'model' => 'required',
            'make' => 'required',
            'color' => 'required',
            'weight' => 'required',
            'price' => 'required'
        ]);

        $image = $request->file('image');
        $input = $request->all();
        $input['image'] = time() . '.' . $image->getClientOriginalExtension();
        $destinationUrl = url('images');
        $destinationPath = public_path('images');
        $image->move($destinationPath, $input['image']);
        $input['image'] = $destinationUrl . '/' . $input['image'];
        //dd($input);
        MotorBike::create($input);
        return redirect('/admin/panel');
    }
}

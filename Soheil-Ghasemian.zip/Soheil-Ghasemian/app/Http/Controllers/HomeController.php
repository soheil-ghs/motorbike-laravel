<?php

namespace App\Http\Controllers;

use App\MotorBike;
use Illuminate\Http\Request;
use Throwable;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $motors = MotorBike::paginate(5);

        if ($request->ajax()) {
            if (isset($request->sort)) {
                $res = $request->sort;

                if ($res == 'price') {
                    $motors = MotorBike::orderBy('price', 'desc')
                        ->paginate(5);
                    try {
                        return view('bikes.load', ['motors' => $motors])->render();
                    } catch (Throwable $e) {
                    }
                } elseif ($res == 'date') {
                    $motors = MotorBike::latest('created_at')
                        ->paginate(5);
                    try {
                        return view('bikes.load', ['motors' => $motors])->render();
                    } catch (Throwable $e) {
                    }
                }
            }

            if (isset($request->color)) {
                $motors = MotorBike::whereColor($request->color)
                    ->paginate(5);
                try {
                    return view('bikes.load', ['motors' => $motors])->render();
                } catch (Throwable $e) {
                }
            }

            if ($request->color == '') {
                $motors = MotorBike::paginate(5);
                try {
                    return view('bikes.load', ['motors' => $motors])->render();
                } catch (Throwable $e) {
                }
            }
        }

        return view('home', compact('motors'));
    }

    public function showMotor(MotorBike $bike)
    {
        return view('show-bikes', compact('bike'));
    }

    /*public function sortAjax(Request $request)
    {
        $motors = [];
        $res = $request->sort;
        if ($res == 'price') {
            $motors = MotorBike::orderBy('price')
                ->paginate(5);
            foreach ($motors as $motor) {
                dd($motor);
            }
        }
    }*/
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MotorBike extends Model
{

    protected $fillable = [
        'model',
        'make',
        'color',
        'weight',
        'price',
        'image',
        'description'
    ];
}
